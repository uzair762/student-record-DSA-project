
package P1;// NotificationQueue.java
import java.util.LinkedList;
import java.util.Queue;

public class NotificationQueue implements INotificationService {
    private final Queue<String> notificationQueue;

    public NotificationQueue() {
        this.notificationQueue = new LinkedList<>();
    }

    @Override
    public void enqueueNotification(String message) {
        notificationQueue.offer(message);
    }

    @Override
    public String processNextNotification() {
        if (!notificationQueue.isEmpty()) {
            return notificationQueue.poll();
        }
        return "No pending notifications.";
    }

    @Override
    public int getQueueSize() {
        return notificationQueue.size();
    }
}