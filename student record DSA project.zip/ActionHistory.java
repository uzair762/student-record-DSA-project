
package P1;// ActionHistory.java
import java.util.Stack;

public class ActionHistory implements IHistoryManager {
    private final Stack<String> historyStack;

    public ActionHistory() {
        this.historyStack = new Stack<>();
    }

    @Override
    public void recordAction(String actionDetail) {
        historyStack.push(actionDetail);
        if (historyStack.size() > 100) {
            historyStack.remove(0);
        }
    }

    @Override
    public String undoLastAction() {
        if (!historyStack.isEmpty()) {
            return historyStack.pop();
        }
        return "No actions to undo.";
    }

    @Override
    public Stack<String> getHistoryStack() {
        return historyStack;
    }
}