
package P1;// IContactStorage.java
import java.util.Collection;

public interface IContactStorage {
    boolean addContact(Contact contact);
    Contact searchContact(String phoneNumber);
    boolean deleteContact(String phoneNumber);
    boolean updateContact(String oldPhoneNumber, Contact updatedContact);
    Collection<Contact> getAllContacts();
}