
package P1;// ContactManager.java (COMPLETE & FIXED)
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ContactManager {
    
    private final IContactStorage storage;
    private final IHistoryManager historyManager; 
    private final INotificationService notificationService; 
    private final IRelationshipManager relationshipManager;
    private final ContactTrie contactTrie;

    public ContactManager(IContactStorage storage, IHistoryManager historyManager, 
                         INotificationService notificationService, 
                         IRelationshipManager relationshipManager, ContactTrie contactTrie) {
        this.storage = storage;
        this.historyManager = historyManager;
        this.notificationService = notificationService;
        this.relationshipManager = relationshipManager;
        this.contactTrie = contactTrie;
        
        this.historyManager.recordAction("System Initialized.");
        this.notificationService.enqueueNotification("System ready for user input.");
    }
    
    // --- Basic CRUD Operations ---
    
    public boolean addNewContact(Contact contact) {
        boolean success = storage.addContact(contact);
        if (success) {
            historyManager.recordAction("Added Contact: " + contact.getName());
            notificationService.enqueueNotification("Successfully added " + contact.getName());
            contactTrie.insert(contact.getName(), contact.getPhoneNumber());
        }
        return success;
    }
    
    public boolean removeContact(String phoneNumber) {
        Contact contact = storage.searchContact(phoneNumber);
        if (contact != null && storage.deleteContact(phoneNumber)) {
            historyManager.recordAction("Deleted Contact: " + contact.getName());
            contactTrie.rebuildTrie(storage.getAllContacts());
            return true;
        }
        return false;
    }
    
    public boolean modifyContact(String oldPhone, Contact updatedContact) {
        boolean success = storage.updateContact(oldPhone, updatedContact);
        if (success) {
            historyManager.recordAction("Updated contact from " + oldPhone + " to " + updatedContact.getPhoneNumber());
            contactTrie.rebuildTrie(storage.getAllContacts());
        }
        return success;
    }
    
    // --- New DSA Feature Methods ---
    
    public List<Contact> searchContactsByPrefix(String prefix) {
        List<String> phoneNumbers = contactTrie.searchByPrefix(prefix);
        List<Contact> contacts = new ArrayList<>();
        for (String phone : phoneNumbers) {
            Contact contact = storage.searchContact(phone);
            if (contact != null) {
                contacts.add(contact);
            }
        }
        return contacts;
    }
    
    public void addRelationship(String phoneA, String phoneB, String type) {
        relationshipManager.addRelationship(phoneA, phoneB, type);
        historyManager.recordAction("Added relationship: " + phoneA + " <-> " + phoneB + " (" + type + ")");
    }
    
    public List<Contact> getRelatedContacts(String phoneA) {
        return relationshipManager.getRelatedContacts(phoneA, storage);
    }
    
    // NEW: Get relationship type
    public String getRelationshipType(String phoneA, String phoneB) {
        return relationshipManager.getRelationshipType(phoneA, phoneB);
    }
    
    // --- Getters ---
    public IContactStorage getStorage() { return storage; }
    public IHistoryManager getHistoryManager() { return historyManager; }
    public INotificationService getNotificationService() { return notificationService; }
    public IRelationshipManager getRelationshipManager() { return relationshipManager; }
    public ContactTrie getContactTrie() { return contactTrie; }
    
    // --- Additional Methods ---
    public Contact findContact(String phoneNumber) {
        return storage.searchContact(phoneNumber);
    }

    public Collection<Contact> retrieveAllContacts() {
        return storage.getAllContacts();
    }
}