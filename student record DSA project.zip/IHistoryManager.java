
package P1;// IHistoryManager.java
import java.util.Stack;

public interface IHistoryManager {
    void recordAction(String actionDetail); 
    String undoLastAction(); 
    Stack<String> getHistoryStack(); 
}