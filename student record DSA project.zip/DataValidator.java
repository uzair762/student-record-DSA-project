
package P1;// DataValidator.java
public class DataValidator {
    
    public static boolean isValidName(String name) {
        return name != null && !name.trim().isEmpty() && name.length() >= 2;
    }
    
    public static boolean isValidPhone(String phone) {
        return phone != null && phone.matches("\\d{11}") && phone.startsWith("03");
    }
    
    public static boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return true; // Email is optional
        }
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        return email.matches(emailRegex);
    }
    
    public static boolean isValidAddress(String address) {
        return address != null; // Address can be empty but not null
    }
    
    public static String formatPhone(String phone) {
        if (phone == null) return "";
        phone = phone.replaceAll("[^\\d]", "");
        if (phone.length() == 11 && phone.startsWith("03")) {
            return phone.substring(0, 4) + "-" + phone.substring(4, 7) + "-" + phone.substring(7);
        }
        return phone;
    }
}
