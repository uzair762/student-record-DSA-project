
package P1;// IRelationshipManager.java
import java.util.List;

public interface IRelationshipManager {
    // Add an edge (relationship) between two contacts (identified by phone number)
    void addRelationship(String phoneA, String phoneB, String type);
    
    // Get all neighbors (related contacts) of a contact
    List<Contact> getRelatedContacts(String phoneA, IContactStorage storage);
    
    // Check if a relationship exists
    boolean hasRelationship(String phoneA, String phoneB);
    
    // NEW: Get relationship type between two contacts
    String getRelationshipType(String phoneA, String phoneB);
}