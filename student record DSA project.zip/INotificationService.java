
package P1;// INotificationService.java
public interface INotificationService {
    void enqueueNotification(String message);
    String processNextNotification();
    int getQueueSize();
}