
package P1; // MainApplication.java (REDESIGNED with Dark Theme)
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class MainApplication extends JFrame {
    
    // Core Dependencies
    private final ContactManager manager;
    
    // Layout and Panels
    private final CardLayout cardLayout;
    private final JPanel mainContainer;
    
    // Colors for Dark Theme
    private final Color DARK_BG = new Color(30, 30, 40);
    private final Color DARKER_BG = new Color(20, 20, 30);
    private final Color ACCENT_COLOR = new Color(0, 150, 255);
    private final Color SECONDARY_ACCENT = new Color(255, 100, 100);
    private final Color TEXT_COLOR = new Color(240, 240, 245);
    private final Color CARD_BG = new Color(40, 40, 50);
    
    // Components
    private JTable contactTable;
    private DefaultTableModel tableModel;
    private JTextArea historyDisplay, queueDisplay;
    private JTextField nameField, phoneField, emailField, addressField;
    private JTextField prefixSearchField;

    public MainApplication(ContactManager manager) {
        this.manager = manager;
        initializeDummyData();
        
        // Setup frame
        setTitle("📞 Advanced Contact Management System");
        setSize(1400, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Set dark theme
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Setup container
        cardLayout = new CardLayout();
        mainContainer = new JPanel(cardLayout);
        mainContainer.setBackground(DARK_BG);
        
        // Create panels
        mainContainer.add(createWelcomePanel(), "WELCOME");
        mainContainer.add(createCategoriesPanel(), "CATEGORIES");
        mainContainer.add(createContactListPanel(), "CONTACT_LIST");
        
        add(mainContainer);
        cardLayout.show(mainContainer, "WELCOME");
        setVisible(true);
    }
    
    private void initializeDummyData() {
        manager.addNewContact(new Contact("Ali Khan", "03001234567", "ali.khan@example.com", "Lahore"));
        manager.addNewContact(new Contact("Sara Ahmed", "03339876543", "sara.ahmed@mail.com", "Karachi"));
        manager.addNewContact(new Contact("Ahmed Raja", "03110001112", "ahmed.r@test.com", "Islamabad"));
        
        manager.addRelationship("03001234567", "03339876543", "Family");
        manager.addRelationship("03001234567", "03110001112", "Colleague");
    }
    
    // Helper method to create styled buttons
    private JButton createStyledButton(String text, Color color, Font font) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Create gradient
                GradientPaint gradient = new GradientPaint(
                    0, 0, color,
                    0, getHeight(), color.darker()
                );
                g2.setPaint(gradient);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                
                // Add shadow
                g2.setColor(new Color(0, 0, 0, 100));
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 25, 25);
                
                g2.dispose();
                super.paintComponent(g);
            }
        };
        
        button.setFont(font);
        button.setForeground(Color.WHITE);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setBorder(BorderFactory.createEmptyBorder(12, 30, 12, 30));
        
        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });
        
        return button;
    }
    
    private JPanel createStyledCard() {
        JPanel card = new JPanel();
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(60, 60, 70), 1),
            new EmptyBorder(20, 20, 20, 20)
        ));
        return card;
    }
    
    // --- 1. WELCOME PAGE ---
    private JPanel createWelcomePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(DARK_BG);
        
        // Top bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(ACCENT_COLOR);
        topBar.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        
        JLabel welcomeLabel = new JLabel("🚀 Advanced CMS v2.0");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        welcomeLabel.setForeground(Color.WHITE);
        topBar.add(welcomeLabel, BorderLayout.WEST);
        
        JLabel versionLabel = new JLabel("Built with OOP & DSA Principles");
        versionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        versionLabel.setForeground(new Color(220, 220, 255));
        topBar.add(versionLabel, BorderLayout.EAST);
        
        // Main content
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(DARK_BG);
        content.setBorder(BorderFactory.createEmptyBorder(60, 100, 60, 100));
        
        // Title
        JLabel title = new JLabel("Contact Management System");
        title.setFont(new Font("Segoe UI", Font.BOLD, 42));
        title.setForeground(TEXT_COLOR);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Subtitle
        JLabel subtitle = new JLabel("Professional • Secure • Efficient");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        subtitle.setForeground(new Color(180, 180, 220));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Features card
        JPanel featuresCard = createStyledCard();
        featuresCard.setLayout(new BorderLayout());
        
        JTextArea featuresText = new JTextArea();
        featuresText.setText(
            "✨ CORE FEATURES:\n\n" +
            "• HashMap Storage (O1 CRUD Operations)\n" +
            "• Stack-based History (Undo Support)\n" +
            "• Queue-based Notifications (FIFO)\n" +
            "• Trie Tree (Prefix Search)\n" +
            "• Graph Relationships (Contact Networking)\n" +
            "• Modern Dark Theme Interface\n\n" +
            "Click 'START' to begin your journey!"
        );
        featuresText.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        featuresText.setForeground(TEXT_COLOR);
        featuresText.setBackground(CARD_BG);
        featuresText.setEditable(false);
        featuresText.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
        
        featuresCard.add(featuresText, BorderLayout.CENTER);
        
        // Start button
        JButton startButton = createStyledButton("🎯 START CMS", ACCENT_COLOR, new Font("Segoe UI", Font.BOLD, 24));
        startButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        startButton.setMaximumSize(new Dimension(300, 70));
        startButton.addActionListener(e -> {
            cardLayout.show(mainContainer, "CATEGORIES");
            refreshContactTable();
        });
        
        // Assembly
        content.add(Box.createVerticalStrut(30));
        content.add(title);
        content.add(Box.createVerticalStrut(10));
        content.add(subtitle);
        content.add(Box.createVerticalStrut(50));
        content.add(featuresCard);
        content.add(Box.createVerticalStrut(50));
        content.add(startButton);
        
        panel.add(topBar, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        
        return panel;
    }
    
    // --- 2. CATEGORIES PAGE ---
    private JPanel createCategoriesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(DARK_BG);
        
        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(DARKER_BG);
        header.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        
        JLabel title = new JLabel("📁 FUNCTION CATEGORIES");
        title.setFont(new Font("Segoe UI", Font.BOLD, 32));
        title.setForeground(TEXT_COLOR);
        
        JButton backButton = createStyledButton("← Back to Welcome", new Color(100, 100, 120), 
                                               new Font("Segoe UI", Font.BOLD, 14));
        backButton.addActionListener(e -> cardLayout.show(mainContainer, "WELCOME"));
        
        header.add(title, BorderLayout.WEST);
        header.add(backButton, BorderLayout.EAST);
        
        // Categories Grid
        JPanel categoriesGrid = new JPanel(new GridLayout(2, 3, 30, 30));
        categoriesGrid.setBackground(DARK_BG);
        categoriesGrid.setBorder(BorderFactory.createEmptyBorder(40, 60, 40, 60));
        
        // Category buttons
        JButton contactBtn = createCategoryButton(
            "📇 CONTACT MANAGEMENT",
            "Add, edit, delete and view all contacts",
            ACCENT_COLOR
        );
        contactBtn.addActionListener(e -> {
            cardLayout.show(mainContainer, "CONTACT_LIST");
            refreshContactTable();
        });
        
        JButton searchBtn = createCategoryButton(
            "🔍 ADVANCED SEARCH",
            "Trie-based prefix search and filtering",
            new Color(100, 200, 100)
        );
        searchBtn.addActionListener(e -> showSearchDialog());
        
        JButton relationBtn = createCategoryButton(
            "🌐 RELATIONSHIP MANAGER",
            "Graph-based contact networking",
            new Color(255, 150, 50)
        );
        relationBtn.addActionListener(e -> showRelationshipDialog());
        
        JButton historyBtn = createCategoryButton(
            "📊 HISTORY & LOGS",
            "View action history and undo operations",
            new Color(200, 100, 200)
        );
        historyBtn.addActionListener(e -> showHistoryDialog());
        
        JButton notifyBtn = createCategoryButton(
            "🔔 NOTIFICATIONS",
            "Manage notification queue and alerts",
            new Color(255, 100, 100)
        );
        notifyBtn.addActionListener(e -> showNotificationsDialog());
        
        JButton infoBtn = createCategoryButton(
            "⚙️ SYSTEM INFO",
            "View system statistics and settings",
            new Color(100, 180, 255)
        );
        infoBtn.addActionListener(e -> showSystemInfoDialog());
        
        // Add buttons to grid
        categoriesGrid.add(contactBtn);
        categoriesGrid.add(searchBtn);
        categoriesGrid.add(relationBtn);
        categoriesGrid.add(historyBtn);
        categoriesGrid.add(notifyBtn);
        categoriesGrid.add(infoBtn);
        
        panel.add(header, BorderLayout.NORTH);
        panel.add(categoriesGrid, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JButton createCategoryButton(String title, String description, Color color) {
        JButton button = new JButton();
        button.setLayout(new BorderLayout(10, 10));
        button.setBackground(CARD_BG);
        button.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(color, 2),
            new EmptyBorder(20, 20, 20, 20)
        ));
        button.setPreferredSize(new Dimension(250, 150));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(color);
        
        JTextArea descArea = new JTextArea(description);
        descArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descArea.setForeground(TEXT_COLOR);
        descArea.setBackground(CARD_BG);
        descArea.setEditable(false);
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        
        button.add(titleLabel, BorderLayout.NORTH);
        button.add(descArea, BorderLayout.CENTER);
        
        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(CARD_BG.brighter());
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(CARD_BG);
                button.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });
        
        return button;
    }
    
    // --- 3. CONTACT LIST PAGE ---
    private JPanel createContactListPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(DARK_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(DARKER_BG);
        header.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel title = new JLabel("📋 CONTACT LIST & OPERATIONS");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(TEXT_COLOR);
        
        JButton backButton = createStyledButton("← Back to Categories", 
                                               new Color(100, 100, 120),
                                               new Font("Segoe UI", Font.BOLD, 14));
        backButton.addActionListener(e -> cardLayout.show(mainContainer, "CATEGORIES"));
        
        header.add(title, BorderLayout.WEST);
        header.add(backButton, BorderLayout.EAST);
        
        // Main content
        JPanel content = new JPanel(new BorderLayout(15, 15));
        content.setBackground(DARK_BG);
        
        // Input Panel
        JPanel inputPanel = createInputPanel();
        
        // Action Buttons
        JPanel actionPanel = createActionPanel();
        
        // Table
        JPanel tablePanel = createTablePanel();
        
        // DSA Features Panel
        JPanel dsaPanel = createDSAPanel();
        
        // Assembly
        JPanel topSection = new JPanel(new BorderLayout(10, 10));
        topSection.setBackground(DARK_BG);
        topSection.add(inputPanel, BorderLayout.NORTH);
        topSection.add(actionPanel, BorderLayout.CENTER);
        
        JSplitPane mainSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tablePanel, dsaPanel);
        mainSplit.setResizeWeight(0.6);
        mainSplit.setDividerSize(5);
        
        content.add(topSection, BorderLayout.NORTH);
        content.add(mainSplit, BorderLayout.CENTER);
        
        panel.add(header, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createInputPanel() {
        JPanel panel = createStyledCard();
        panel.setLayout(new GridLayout(2, 4, 15, 10));
        
        Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
        Font fieldFont = new Font("Segoe UI", Font.PLAIN, 14);
        
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(labelFont);
        nameLabel.setForeground(TEXT_COLOR);
        
        nameField = new JTextField();
        nameField.setFont(fieldFont);
        nameField.setBackground(new Color(50, 50, 60));
        nameField.setForeground(TEXT_COLOR);
        nameField.setCaretColor(TEXT_COLOR);
        
        JLabel phoneLabel = new JLabel("Phone (Key):");
        phoneLabel.setFont(labelFont);
        phoneLabel.setForeground(TEXT_COLOR);
        
        phoneField = new JTextField();
        phoneField.setFont(fieldFont);
        phoneField.setBackground(new Color(50, 50, 60));
        phoneField.setForeground(TEXT_COLOR);
        phoneField.setCaretColor(TEXT_COLOR);
        
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(labelFont);
        emailLabel.setForeground(TEXT_COLOR);
        
        emailField = new JTextField();
        emailField.setFont(fieldFont);
        emailField.setBackground(new Color(50, 50, 60));
        emailField.setForeground(TEXT_COLOR);
        emailField.setCaretColor(TEXT_COLOR);
        
        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setFont(labelFont);
        addressLabel.setForeground(TEXT_COLOR);
        
        addressField = new JTextField();
        addressField.setFont(fieldFont);
        addressField.setBackground(new Color(50, 50, 60));
        addressField.setForeground(TEXT_COLOR);
        addressField.setCaretColor(TEXT_COLOR);
        
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(phoneLabel);
        panel.add(phoneField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(addressLabel);
        panel.add(addressField);
        
        return panel;
    }
    
    private JPanel createActionPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panel.setBackground(DARK_BG);
        
        JButton addBtn = createStyledButton("➕ Add Contact", ACCENT_COLOR, 
                                          new Font("Segoe UI", Font.BOLD, 14));
        addBtn.addActionListener(this::handleAdd);
        
        JButton updateBtn = createStyledButton("✏️ Update Contact", new Color(255, 200, 0),
                                             new Font("Segoe UI", Font.BOLD, 14));
        updateBtn.addActionListener(this::handleUpdate);
        
        JButton deleteBtn = createStyledButton("🗑️ Delete Contact", SECONDARY_ACCENT,
                                             new Font("Segoe UI", Font.BOLD, 14));
        deleteBtn.addActionListener(this::handleDelete);
        
        JButton searchBtn = createStyledButton("🔍 Search by Phone", new Color(100, 200, 100),
                                             new Font("Segoe UI", Font.BOLD, 14));
        searchBtn.addActionListener(this::handleSearch);
        
        JButton refreshBtn = createStyledButton("🔄 Refresh List", new Color(150, 100, 255),
                                              new Font("Segoe UI", Font.BOLD, 14));
        refreshBtn.addActionListener(e -> refreshContactTable());
        
        panel.add(addBtn);
        panel.add(updateBtn);
        panel.add(deleteBtn);
        panel.add(searchBtn);
        panel.add(refreshBtn);
        
        return panel;
    }
    
    private JPanel createTablePanel() {
        JPanel panel = createStyledCard();
        panel.setLayout(new BorderLayout());
        
        // Table setup
        String[] columns = {"Name", "Phone Number", "Email", "Address"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        contactTable = new JTable(tableModel);
        contactTable.setBackground(new Color(50, 50, 60));
        contactTable.setForeground(TEXT_COLOR);
        contactTable.setSelectionBackground(ACCENT_COLOR);
        contactTable.setSelectionForeground(Color.WHITE);
        contactTable.setGridColor(new Color(70, 70, 80));
        contactTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        contactTable.setRowHeight(25);
        
        // Header styling
        contactTable.getTableHeader().setBackground(DARKER_BG);
        contactTable.getTableHeader().setForeground(TEXT_COLOR);
        contactTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        JScrollPane scrollPane = new JScrollPane(contactTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(60, 60, 70)),
            "📊 Contact Database (HashMap Storage)",
            TitledBorder.LEFT,
            TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 14),
            TEXT_COLOR
        ));
        
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Add table row selection listener
        contactTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && contactTable.getSelectedRow() != -1) {
                int row = contactTable.getSelectedRow();
                nameField.setText((String) tableModel.getValueAt(row, 0));
                phoneField.setText((String) tableModel.getValueAt(row, 1));
                emailField.setText((String) tableModel.getValueAt(row, 2));
                addressField.setText((String) tableModel.getValueAt(row, 3));
            }
        });
        
        return panel;
    }
    
    private JPanel createDSAPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 2, 15, 0));
        panel.setBackground(DARK_BG);
        
        // History Panel
        JPanel historyPanel = createStyledCard();
        historyPanel.setLayout(new BorderLayout(10, 10));
        
        JLabel historyLabel = new JLabel("📜 Action History (Stack - LIFO)");
        historyLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        historyLabel.setForeground(TEXT_COLOR);
        
        historyDisplay = new JTextArea();
        historyDisplay.setBackground(new Color(50, 50, 60));
        historyDisplay.setForeground(TEXT_COLOR);
        historyDisplay.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        historyDisplay.setEditable(false);
        historyDisplay.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JPanel historyButtons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        historyButtons.setBackground(CARD_BG);
        
        JButton undoBtn = createStyledButton("↩️ Undo Last Action", 
                                           new Color(255, 150, 0),
                                           new Font("Segoe UI", Font.BOLD, 12));
        undoBtn.addActionListener(this::handleUndo);
        
        JButton refreshHistoryBtn = createStyledButton("🔄 Refresh History",
                                                     new Color(100, 150, 255),
                                                     new Font("Segoe UI", Font.BOLD, 12));
        refreshHistoryBtn.addActionListener(this::handleListHistory);
        
        historyButtons.add(undoBtn);
        historyButtons.add(refreshHistoryBtn);
        
        historyPanel.add(historyLabel, BorderLayout.NORTH);
        historyPanel.add(new JScrollPane(historyDisplay), BorderLayout.CENTER);
        historyPanel.add(historyButtons, BorderLayout.SOUTH);
        
        // Queue Panel
        JPanel queuePanel = createStyledCard();
        queuePanel.setLayout(new BorderLayout(10, 10));
        
        JLabel queueLabel = new JLabel("🔔 Notification Queue (FIFO)");
        queueLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        queueLabel.setForeground(TEXT_COLOR);
        
        queueDisplay = new JTextArea();
        queueDisplay.setBackground(new Color(50, 50, 60));
        queueDisplay.setForeground(TEXT_COLOR);
        queueDisplay.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        queueDisplay.setEditable(false);
        queueDisplay.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JButton processQueueBtn = createStyledButton("➡️ Process Next Notification",
                                                   new Color(100, 200, 100),
                                                   new Font("Segoe UI", Font.BOLD, 12));
        processQueueBtn.addActionListener(this::handleProcessQueue);
        
        queuePanel.add(queueLabel, BorderLayout.NORTH);
        queuePanel.add(new JScrollPane(queueDisplay), BorderLayout.CENTER);
        queuePanel.add(processQueueBtn, BorderLayout.SOUTH);
        
        panel.add(historyPanel);
        panel.add(queuePanel);
        
        return panel;
    }
    
    // --- Dialog Methods ---
    
    private void showSearchDialog() {
        JDialog dialog = new JDialog(this, "🔍 Advanced Search (Trie)", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(DARK_BG);
        
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(DARK_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel title = new JLabel("Trie-Based Prefix Search");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(TEXT_COLOR);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        inputPanel.setBackground(DARK_BG);
        
        JLabel prefixLabel = new JLabel("Enter prefix:");
        prefixLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        prefixLabel.setForeground(TEXT_COLOR);
        
        JTextField searchField = new JTextField(15);
        searchField.setBackground(new Color(50, 50, 60));
        searchField.setForeground(TEXT_COLOR);
        searchField.setCaretColor(TEXT_COLOR);
        
        JButton searchBtn = createStyledButton("🔎 Search", ACCENT_COLOR,
                                             new Font("Segoe UI", Font.BOLD, 14));
        
        inputPanel.add(prefixLabel);
        inputPanel.add(searchField);
        inputPanel.add(searchBtn);
        
        JTextArea resultArea = new JTextArea();
        resultArea.setBackground(new Color(50, 50, 60));
        resultArea.setForeground(TEXT_COLOR);
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        searchBtn.addActionListener(e -> {
            String prefix = searchField.getText().trim();
            if (prefix.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Please enter a search prefix.", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            List<Contact> results = manager.searchContactsByPrefix(prefix);
            StringBuilder sb = new StringBuilder();
            sb.append("Search Results for '").append(prefix).append("':\n");
            sb.append("══════════════════════════════\n\n");
            
            if (results.isEmpty()) {
                sb.append("No contacts found.\n");
            } else {
                for (Contact c : results) {
                    sb.append("• ").append(c.getName()).append("\n");
                    sb.append("  Phone: ").append(c.getPhoneNumber()).append("\n");
                    sb.append("  Email: ").append(c.getEmail()).append("\n");
                    sb.append("  Address: ").append(c.getAddress()).append("\n\n");
                }
                sb.append("Total found: ").append(results.size()).append(" contacts\n");
            }
            
            resultArea.setText(sb.toString());
        });
        
        panel.add(title, BorderLayout.NORTH);
        panel.add(inputPanel, BorderLayout.CENTER);
        panel.add(new JScrollPane(resultArea), BorderLayout.SOUTH);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void showRelationshipDialog() {
        JDialog dialog = new JDialog(this, "🌐 Relationship Manager (Graph)", true);
        dialog.setSize(600, 500);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(DARK_BG);
        
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(DARK_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Input section
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        inputPanel.setBackground(CARD_BG);
        inputPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JTextField phoneAField = new JTextField();
        JTextField phoneBField = new JTextField();
        JTextField typeField = new JTextField();
        
        Font labelFont = new Font("Segoe UI", Font.BOLD, 13);
        Font fieldFont = new Font("Segoe UI", Font.PLAIN, 13);
        
        JLabel label1 = new JLabel("Contact A Phone:");
        label1.setFont(labelFont);
        label1.setForeground(TEXT_COLOR);
        
        phoneAField.setBackground(new Color(50, 50, 60));
        phoneAField.setForeground(TEXT_COLOR);
        phoneAField.setCaretColor(TEXT_COLOR);
        phoneAField.setFont(fieldFont);
        
        JLabel label2 = new JLabel("Contact B Phone:");
        label2.setFont(labelFont);
        label2.setForeground(TEXT_COLOR);
        
        phoneBField.setBackground(new Color(50, 50, 60));
        phoneBField.setForeground(TEXT_COLOR);
        phoneBField.setCaretColor(TEXT_COLOR);
        phoneBField.setFont(fieldFont);
        
        JLabel label3 = new JLabel("Relationship Type:");
        label3.setFont(labelFont);
        label3.setForeground(TEXT_COLOR);
        
        typeField.setBackground(new Color(50, 50, 60));
        typeField.setForeground(TEXT_COLOR);
        typeField.setCaretColor(TEXT_COLOR);
        typeField.setFont(fieldFont);
        
        inputPanel.add(label1);
        inputPanel.add(phoneAField);
        inputPanel.add(label2);
        inputPanel.add(phoneBField);
        inputPanel.add(label3);
        inputPanel.add(typeField);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(DARK_BG);
        
        JButton addRelationBtn = createStyledButton("🤝 Add Relationship", 
                                                   new Color(100, 200, 100),
                                                   new Font("Segoe UI", Font.BOLD, 14));
        
        JButton viewRelationBtn = createStyledButton("👁️ View Relationships",
                                                    ACCENT_COLOR,
                                                    new Font("Segoe UI", Font.BOLD, 14));
        
        buttonPanel.add(addRelationBtn);
        buttonPanel.add(viewRelationBtn);
        
        // Results area
        JTextArea resultArea = new JTextArea();
        resultArea.setBackground(new Color(50, 50, 60));
        resultArea.setForeground(TEXT_COLOR);
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        // Button actions
        addRelationBtn.addActionListener(e -> {
            String phoneA = phoneAField.getText().trim();
            String phoneB = phoneBField.getText().trim();
            String type = typeField.getText().trim();
            
            if (phoneA.isEmpty() || phoneB.isEmpty() || type.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "All fields are required!", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (manager.findContact(phoneA) == null || manager.findContact(phoneB) == null) {
                JOptionPane.showMessageDialog(dialog, "One or both contacts not found!", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            manager.addRelationship(phoneA, phoneB, type);
            resultArea.append("✓ Added relationship: " + phoneA + " ↔ " + phoneB + 
                            " (" + type + ")\n");
            
            phoneAField.setText("");
            phoneBField.setText("");
            typeField.setText("");
        });
        
        viewRelationBtn.addActionListener(e -> {
            String phone = JOptionPane.showInputDialog(dialog, 
                "Enter phone number to view relationships:");
            if (phone == null || phone.trim().isEmpty()) return;
            
            List<Contact> related = manager.getRelatedContacts(phone.trim());
            resultArea.setText("Relationships for: " + phone + "\n");
            resultArea.append("══════════════════════════\n\n");
            
            if (related.isEmpty()) {
                resultArea.append("No relationships found.\n");
            } else {
                for (Contact c : related) {
                    String type = ((ContactGraph) manager.getRelationshipManager())
                                  .getRelationshipType(phone, c.getPhoneNumber());
                    resultArea.append("• " + c.getName() + " (" + c.getPhoneNumber() + 
                                    ")\n  Type: " + type + "\n\n");
                }
            }
        });
        
        panel.add(inputPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.add(new JScrollPane(resultArea), BorderLayout.SOUTH);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void showHistoryDialog() {
        JDialog dialog = new JDialog(this, "📊 History & Logs", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(DARK_BG);
        
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(DARK_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JTextArea historyArea = new JTextArea();
        historyArea.setBackground(new Color(50, 50, 60));
        historyArea.setForeground(TEXT_COLOR);
        historyArea.setEditable(false);
        historyArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        // Load history
        List<String> historyList = manager.getHistoryManager().getHistoryStack()
            .stream().collect(Collectors.toList());
        StringBuilder sb = new StringBuilder();
        sb.append("ACTION HISTORY (Most recent first)\n");
        sb.append("══════════════════════════════\n\n");
        
        for (int i = historyList.size() - 1; i >= 0; i--) {
            sb.append(i + 1).append(". ").append(historyList.get(i)).append("\n");
        }
        
        if (historyList.isEmpty()) {
            sb.append("No history recorded yet.\n");
        }
        
        historyArea.setText(sb.toString());
        
        panel.add(new JScrollPane(historyArea), BorderLayout.CENTER);
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void showNotificationsDialog() {
        JDialog dialog = new JDialog(this, "🔔 Notification Queue", true);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(DARK_BG);
        
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(DARK_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JTextArea queueArea = new JTextArea();
        queueArea.setBackground(new Color(50, 50, 60));
        queueArea.setForeground(TEXT_COLOR);
        queueArea.setEditable(false);
        queueArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        int queueSize = manager.getNotificationService().getQueueSize();
        queueArea.setText("Notification Queue Status\n");
        queueArea.append("═════════════════════════\n\n");
        queueArea.append("Pending notifications: " + queueSize + "\n\n");
        queueArea.append("Click 'Process Next' button in main window\n");
        queueArea.append("to process notifications.");
        
        panel.add(new JScrollPane(queueArea), BorderLayout.CENTER);
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void showSystemInfoDialog() {
        JDialog dialog = new JDialog(this, "⚙️ System Information", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(DARK_BG);
        
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(DARK_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JTextArea infoArea = new JTextArea();
        infoArea.setBackground(new Color(50, 50, 60));
        infoArea.setForeground(TEXT_COLOR);
        infoArea.setEditable(false);
        infoArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        StringBuilder sb = new StringBuilder();
        sb.append("SYSTEM INFORMATION\n");
        sb.append("═══════════════════\n\n");
        sb.append("Data Structures Used:\n");
        sb.append("• HashMap (Storage): O(1) CRUD\n");
        sb.append("• Stack (History): LIFO\n");
        sb.append("• Queue (Notifications): FIFO\n");
        sb.append("• Trie Tree (Search): O(L) prefix\n");
        sb.append("• Graph (Relationships): Adjacency List\n\n");
        
        sb.append("System Statistics:\n");
        sb.append("• Total Contacts: " + manager.retrieveAllContacts().size() + "\n");
        sb.append("• History Records: " + manager.getHistoryManager().getHistoryStack().size() + "\n");
        sb.append("• Pending Notifications: " + manager.getNotificationService().getQueueSize() + "\n");
        
        infoArea.setText(sb.toString());
        
        panel.add(new JScrollPane(infoArea), BorderLayout.CENTER);
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    // --- Event Handlers ---
    
    private void handleAdd(ActionEvent e) {
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String email = emailField.getText().trim();
        String address = addressField.getText().trim();
        
        if (name.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Name and Phone Number are required!", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        Contact newContact = new Contact(name, phone, email, address);
        if (manager.addNewContact(newContact)) {
            JOptionPane.showMessageDialog(this, 
                "Contact added successfully!", 
                "Success", JOptionPane.INFORMATION_MESSAGE);
            clearInputFields();
            refreshContactTable();
            handleListHistory(null);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Contact with this phone number already exists!", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void handleUpdate(ActionEvent e) {
        int selectedRow = contactTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select a contact to update!", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String oldPhone = (String) tableModel.getValueAt(selectedRow, 1);
        String newName = nameField.getText().trim();
        String newPhone = phoneField.getText().trim();
        String newEmail = emailField.getText().trim();
        String newAddress = addressField.getText().trim();
        
        if (newName.isEmpty() || newPhone.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Name and Phone are required!", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        Contact updatedContact = new Contact(newName, newPhone, newEmail, newAddress);
        if (manager.modifyContact(oldPhone, updatedContact)) {
            manager.getHistoryManager().recordAction("Updated contact: " + oldPhone + " -> " + newPhone);
            JOptionPane.showMessageDialog(this, 
                "Contact updated successfully!", 
                "Success", JOptionPane.INFORMATION_MESSAGE);
            clearInputFields();
            refreshContactTable();
            handleListHistory(null);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Update failed!", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void handleDelete(ActionEvent e) {
        int selectedRow = contactTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select a contact to delete!", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String phoneToDelete = (String) tableModel.getValueAt(selectedRow, 1);
        String nameToDelete = (String) tableModel.getValueAt(selectedRow, 0);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete:\n" + nameToDelete + "\n(" + phoneToDelete + ")?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            if (manager.removeContact(phoneToDelete)) {
                JOptionPane.showMessageDialog(this, 
                    "Contact deleted successfully!", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
                refreshContactTable();
                handleListHistory(null);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Delete failed!", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void handleSearch(ActionEvent e) {
        String phone = JOptionPane.showInputDialog(this, 
            "Enter phone number to search:");
        if (phone == null || phone.trim().isEmpty()) return;
        
        Contact found = manager.findContact(phone.trim());
        if (found != null) {
            JOptionPane.showMessageDialog(this, 
                "✅ Contact Found:\n" +
                "Name: " + found.getName() + "\n" +
                "Phone: " + found.getPhoneNumber() + "\n" +
                "Email: " + found.getEmail() + "\n" +
                "Address: " + found.getAddress(),
                "Search Result", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, 
                "❌ Contact not found!", 
                "Search Result", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void handleUndo(ActionEvent e) {
        String undone = manager.getHistoryManager().undoLastAction();
        if (undone.equals("No actions to undo.")) {
            JOptionPane.showMessageDialog(this, 
                "No actions to undo!", 
                "Info", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Undid: " + undone, 
                "Undo Successful", JOptionPane.INFORMATION_MESSAGE);
        }
        handleListHistory(null);
    }
    
    private void handleProcessQueue(ActionEvent e) {
        String processed = manager.getNotificationService().processNextNotification();
        if (processed.equals("No pending notifications.")) {
            JOptionPane.showMessageDialog(this, 
                "Queue is empty!", 
                "Info", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Processed: " + processed, 
                "Notification Processed", JOptionPane.INFORMATION_MESSAGE);
        }
        updateQueueDisplay();
    }
    
    private void handleListHistory(ActionEvent e) {
        List<String> historyList = manager.getHistoryManager().getHistoryStack()
            .stream().collect(Collectors.toList());
        StringBuilder sb = new StringBuilder();
        
        for (int i = historyList.size() - 1; i >= 0; i--) {
            sb.append("• ").append(historyList.get(i)).append("\n");
        }
        
        if (historyList.isEmpty()) {
            sb.append("No history recorded yet.\n");
        }
        
        historyDisplay.setText(sb.toString());
        updateQueueDisplay();
    }
    
    private void updateQueueDisplay() {
        int size = manager.getNotificationService().getQueueSize();
        queueDisplay.setText("Pending Notifications: " + size + "\n\n" +
                           "Click 'Process Next Notification' to\n" +
                           "process the next item in queue.");
    }
    
    private void refreshContactTable() {
        tableModel.setRowCount(0);
        Collection<Contact> contacts = manager.retrieveAllContacts();
        
        if (contacts.isEmpty()) {
            tableModel.addRow(new Object[]{"No contacts available", "", "", ""});
        } else {
            for (Contact c : contacts) {
                tableModel.addRow(new Object[]{
                    c.getName(), 
                    c.getPhoneNumber(), 
                    c.getEmail(), 
                    c.getAddress()
                });
            }
        }
    }
    
    private void clearInputFields() {
        nameField.setText("");
        phoneField.setText("");
        emailField.setText("");
        addressField.setText("");
    }
    
    // --- Main Method ---
    public static void main(String[] args) {
        // Initialize dependencies
        IContactStorage storage = new InMemoryStorage();
        IHistoryManager history = new ActionHistory();
        INotificationService notifications = new NotificationQueue();
        IRelationshipManager relationships = new ContactGraph();
        ContactTrie trie = new ContactTrie();
        
        // Create manager
        ContactManager manager = new ContactManager(
            storage, history, notifications, relationships, trie
        );
        
        // Start application
        SwingUtilities.invokeLater(() -> new MainApplication(manager));
    }
}
