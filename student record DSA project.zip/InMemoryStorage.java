
package P1;// InMemoryStorage.java
import java.util.Collection;
import java.util.HashMap;

public class InMemoryStorage implements IContactStorage {
    private final HashMap<String, Contact> contactsMap;

    public InMemoryStorage() {
        this.contactsMap = new HashMap<>();
    }

    @Override
    public boolean addContact(Contact contact) {
        if (contactsMap.containsKey(contact.getPhoneNumber())) {
            return false;
        }
        contactsMap.put(contact.getPhoneNumber(), contact);
        return true;
    }

    @Override
    public Contact searchContact(String phoneNumber) {
        return contactsMap.get(phoneNumber);
    }

    @Override
    public boolean deleteContact(String phoneNumber) {
        return contactsMap.remove(phoneNumber) != null;
    }

    @Override
    public boolean updateContact(String oldPhoneNumber, Contact updatedContact) {
        if (!contactsMap.containsKey(oldPhoneNumber)) {
            return false;
        }
        
        if (!oldPhoneNumber.equals(updatedContact.getPhoneNumber())) {
            contactsMap.remove(oldPhoneNumber);
        }
        
        contactsMap.put(updatedContact.getPhoneNumber(), updatedContact);
        return true;
    }

    @Override
    public Collection<Contact> getAllContacts() {
        return contactsMap.values();
    }
}