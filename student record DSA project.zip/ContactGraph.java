
package P1;// ContactGraph.java
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ContactGraph implements IRelationshipManager {
    private final Map<String, Map<String, String>> adjacencyList;

    public ContactGraph() {
        this.adjacencyList = new HashMap<>();
    }

    @Override
    public void addRelationship(String phoneA, String phoneB, String type) {
        adjacencyList.putIfAbsent(phoneA, new HashMap<>());
        adjacencyList.putIfAbsent(phoneB, new HashMap<>());

        adjacencyList.get(phoneA).put(phoneB, type);
        adjacencyList.get(phoneB).put(phoneA, type);
    }

    @Override
    public List<Contact> getRelatedContacts(String phoneA, IContactStorage storage) {
        List<Contact> related = new ArrayList<>();
        Map<String, String> neighbors = adjacencyList.get(phoneA);
        
        if (neighbors != null) {
            for (String phoneB : neighbors.keySet()) {
                Contact contact = storage.searchContact(phoneB);
                if (contact != null) {
                    related.add(contact);
                }
            }
        }
        return related;
    }

    @Override
    public boolean hasRelationship(String phoneA, String phoneB) {
        return adjacencyList.containsKey(phoneA) && 
               adjacencyList.get(phoneA).containsKey(phoneB);
    }

    @Override
    public String getRelationshipType(String phoneA, String phoneB) {
        if (adjacencyList.containsKey(phoneA) && 
            adjacencyList.get(phoneA).containsKey(phoneB)) {
            return adjacencyList.get(phoneA).get(phoneB);
        }
        return "N/A";
    }
}