
package P1;// ContactTrie.java
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class TrieNode {
    Map<Character, TrieNode> children;
    String contactPhoneNumber;

    public TrieNode() {
        children = new HashMap<>();
        contactPhoneNumber = null;
    }
}

public class ContactTrie {
    private final TrieNode root;

    public ContactTrie() {
        this.root = new TrieNode();
    }

    public void insert(String name, String phoneNumber) {
        TrieNode current = root;
        name = name.toLowerCase();
        
        for (char ch : name.toCharArray()) {
            current.children.putIfAbsent(ch, new TrieNode());
            current = current.children.get(ch);
        }
        current.contactPhoneNumber = phoneNumber;
    }
    
    public List<String> searchByPrefix(String prefix) {
        List<String> results = new ArrayList<>();
        TrieNode current = root;
        prefix = prefix.toLowerCase();

        for (char ch : prefix.toCharArray()) {
            if (!current.children.containsKey(ch)) {
                return results;
            }
            current = current.children.get(ch);
        }

        collectAllPhoneNumbers(current, results);
        return results;
    }
    
    private void collectAllPhoneNumbers(TrieNode node, List<String> results) {
        if (node == null) return;
        
        if (node.contactPhoneNumber != null) {
            results.add(node.contactPhoneNumber);
        }
        
        for (TrieNode child : node.children.values()) {
            collectAllPhoneNumbers(child, results);
        }
    }
    
    public void rebuildTrie(Collection<Contact> contacts) {
        // Clear the trie
        TrieNode newRoot = new TrieNode();
        
        // Rebuild from contacts
        for (Contact contact : contacts) {
            insert(contact.getName(), contact.getPhoneNumber());
        }
    }
}