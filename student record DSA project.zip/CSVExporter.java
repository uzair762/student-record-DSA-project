
package P1;// CSVExporter.java
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;

public class CSVExporter {
    
    public static boolean exportToCSV(Collection<Contact> contacts, String filename) {
        if (filename == null || !filename.endsWith(".csv")) {
            filename = "contacts_export.csv";
        }
        
        try (FileWriter writer = new FileWriter(filename)) {
            // Write header
            writer.write("Name,Phone Number,Email,Address\n");
            
            // Write data
            for (Contact contact : contacts) {
                writer.write(String.format("\"%s\",\"%s\",\"%s\",\"%s\"\n",
                    escapeCsv(contact.getName()),
                    escapeCsv(contact.getPhoneNumber()),
                    escapeCsv(contact.getEmail()),
                    escapeCsv(contact.getAddress())
                ));
            }
            
            SystemLogger.log("Exported " + contacts.size() + " contacts to " + filename);
            return true;
            
        } catch (IOException e) {
            SystemLogger.logError("Failed to export to CSV", e);
            return false;
        }
    }
    
    private static String escapeCsv(String value) {
        if (value == null) return "";
        if (value.contains("\"") || value.contains(",") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }
}